package problem_14;

import java.util.Map;
import java.util.TreeMap;

public class MergeTwoArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int arr1[] = { 10, 5, 15 };
		 int arr2[] = { 20, 3, 2 };
	     int n = arr1.length;
	     int m = arr2.length;
	     mergeArrays(arr1, arr2, n,m);
	}
	
	public static void mergeArrays(int[] arr1, int[] arr2, int n, int m) {
		 Map<Integer, Boolean> mp = new TreeMap<Integer, Boolean>();
		 int i=0;
		 while(i<n) {
			 mp.put(arr1[i], true);
			 i++;
		 }
		 int j=0;
		 while(j<m) {
			 mp.put(arr2[j], true);
			 j++;
		 }
		 
		 for (Map.Entry<Integer, Boolean> val: mp.entrySet() ) {
			System.out.println(val.getKey()+ " ");
		}
		
	}
}
