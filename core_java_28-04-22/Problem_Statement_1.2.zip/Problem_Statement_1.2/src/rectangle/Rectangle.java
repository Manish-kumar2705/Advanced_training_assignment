package rectangle;

import java.util.Scanner;

public class Rectangle {
	
	int length;
	int breadth;
	int area;
	public Rectangle(int length, int breadth, int area) {
		super();
		this.length = 0;
		this.breadth = 0;
		this.area = 0;
	}
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter length of rectangle: ");
        this.length = sc.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        this.breadth = sc.nextInt();
	}
	void calculate() {
		area = length*breadth;
	}
	void display() {
		System.out.println("area of rectangle is :" + area);
	}
	
	
	
}
