package sequence;

import java.util.Scanner;

public class Sequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		int a=sc.nextInt();
		sc.nextLine();
		int b= sc.nextInt();
		sc.nextLine();
		System.out.print(a + "\t");
		System.out.println(b);
		int c;
		c=a+b;//4
		for (int i = 1; i <= 13; i++) {
			if(i==1) 
				{System.out.print(a + " ,");}
			if(i==2) {
				System.out.print(b + " ,");}
			if(i>=3){
				
				System.out.print(c+" ,");
				a=b;
				b=c;
				c=a+b;
			}
		}
	}

}
