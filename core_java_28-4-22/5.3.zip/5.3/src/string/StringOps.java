package string;

import java.util.Scanner;

public class StringOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name= "";
		Scanner sc= new Scanner(System.in);
		name=sc.nextLine();
		System.out.println(name);
		char arr[]=name.toCharArray();
		char temp;
		for(int i = 0; i<arr.length; i++) {
			temp=arr[0];
			int j=1;
			
			while(j<arr.length) {
			arr[j-1]=arr[j];
			j++;
			}
			
			arr[j-1]=temp;
			System.out.println(arr);
			
		} 
	}

}
