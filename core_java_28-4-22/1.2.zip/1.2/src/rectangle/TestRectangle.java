package rectangle;

public class TestRectangle {

	public static void main(String[] args) {
		Rectangle  obj1 = new Rectangle(0, 0, 0);
		obj1.input();
		obj1.calculate();
		obj1.display();
		System.out.println("\n");
		Rectangle  obj2 = new Rectangle(0, 0, 0);
		obj2.input();
		obj2.calculate();
		obj2.display();
		System.out.println("\n");
		Rectangle  obj3 = new Rectangle(0, 0, 0);
		obj3.input();
		obj3.calculate();
		obj3.display();
		System.out.println("\n");
		Rectangle  obj4 = new Rectangle(0, 0, 0);
		obj4.input();
		obj4.calculate();
		obj4.display();
		System.out.println("\n");
		Rectangle  obj5 = new Rectangle(0, 0, 0);
		obj5.input();
		obj5.calculate();
		obj5.display();
		System.out.println("\n");
		System.out.println("execution completed");
	}

}
