package even;


import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			
			System.out.println("enter the value of n");
			int n= sc.nextInt();
			for (int i = 1; (i <= n) ; i++) {
				if(i%2==0)
				System.out.println(" "+i);
				}
			
				
		}
	}
}

