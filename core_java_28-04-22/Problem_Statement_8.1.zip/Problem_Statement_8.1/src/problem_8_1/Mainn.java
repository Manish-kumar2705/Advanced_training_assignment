package problem_8_1;

public class Mainn {

	public static void main(String[] args)   throws InterruptedException {
		// TODO Auto-generated method stub
		
		Storage s = new Storage();
		Counter c = new Counter(s);
		Printer p = new Printer(s);//calls the constructor
		
		Thread t1= new Thread(c); 
		t1.start();
	
		//can also use synchronization between multiple threads
		
	}

}
