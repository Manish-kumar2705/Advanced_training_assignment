package rectangle;

import java.util.Scanner;

public class Rectangle {
	
	float length;
	float breadth;
	float area;
	float perimeter;
	public Rectangle(float length, float breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	void calculateArea() {
		area = length*breadth;
	}
	void calculatePerimeter() {
		perimeter=2*(length+breadth);
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		if(length>0 && length<20)
			this.length = length;
			else {
				System.err.print("enter value from 0 to 20");
				System.exit(0);
			}
	}
	public float getBreadth() {
		return breadth;
	}
	public void setBreadth(float breadth) {
		if(breadth>0 && breadth<20)
		this.breadth = breadth;
		else {
			System.err.println("enter value from 0 to 20");
			System.exit(0);
		}
	}
	void displayArea() {
		System.out.println("area of rectangle is :" + area);
	}
	void displayPerimeter() {
		System.out.println("perimeter of rectangle is :" + perimeter);
	}
	
	
	
}
