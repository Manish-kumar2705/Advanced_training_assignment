package fileex;

class NameNotValidException extends Exception
{
     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String validname()
     {
          return ("Name is not Valid..Please ReEnter the Name");
     }
}