package medicine;

interface MedicineInfo {
	 void displayLabel();
				
	}

class Tablet implements MedicineInfo{
		 
		public void displayLabel()
		{
			System.out.println("store in a cool dry place");
		}
	}
class Syrup implements MedicineInfo
{
	public void displayLabel(){
		System.out.println("Consumption as directed by thephysician");
		}
	}
class Ointment implements MedicineInfo
{	public void displayLabel(){
	System.out.println("for external use only");}
}

