package bank;

public class BankAccount {
int accNo;
float balance;
String custName, accType;



public BankAccount(int accNo, float balance, String custName, String accType) {
	super();
	this.accNo = accNo;
	this.balance = balance;
	this.custName = custName;
	this.accType = accType;
}

public void deposit(float amt) throws Exception {
	if(amt<0)
		throw new NumberFormatException("cant deposte to negative amount");
	else
		{
		balance = getBalance()+amt;
	System.out.println(amt+"deposited successfully");
		}
}

public void withdraw(float amt) throws Exception{
	if(accType.equalsIgnoreCase("savings")) {
		if(getBalance()-amt<1000) {
			throw new Exception("insufficinet funds, transaction cancelled.");
		}
		else
		{
			balance=getBalance()-amt;
		}
	}
	if(accType.equalsIgnoreCase("current account")) {
		if(getBalance()-amt<5000) {
			throw new Exception("insufficinet funds, transaction cancelled.");
		}
		else
		{
			balance=getBalance()-amt;
		}
	}
}

public float getBalance() throws Exception{
	
	 if( balance <1000)
     {
     try
     {   
         throw new NumberFormatException();
     }
     catch(NumberFormatException nw)
     {
         System.out.println("Balance is low"+balance);
     }
     }
    
    
     return balance;
}
void display() throws Exception
{
System.out.println("Balance is ="+getBalance());   
}

	public static void main(String[] args) throws Exception {
    
    
    BankAccount b=new BankAccount(8501654,10000f,"manish","savings");
    b.deposit(5000);
    b.display();
    b.withdraw(14000);
    b.display();
    b.withdraw(200);
    b.getBalance();
    b.display();
   
	}
}
