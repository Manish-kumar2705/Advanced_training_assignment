
public class ArrayComputation {
	public static void main(String[] args) {  
        
        int arr[];
        arr= new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
        System.out.println(arr.length);
        int sum = 0; 
        int i=0;
        for (i = 0; i <= 14; i++) {  
           sum = sum + arr[i]; 
           }
        arr[i]=sum;
        System.out.println( "sum upto 14th index is stored at 15th index:"+sum);
        for (int j : arr) {
			System.out.print(j+" ,");
		}
        
        System.out.println();

         int avg=sum/18;
         System.out.println("Average of all elements in an array is : "+avg);
         arr[++i]=avg;
         System.out.println("Average is stored at 16th index : "+avg);
        for (int j = 0; j < arr.length; j++) {  
            System.out.print(arr[j]+", ");  
         }
        

        int size=arr.length;
        int temp;
        for(int j = 0; j<size; i++ ){
            for(int k = j+1; k<size; k++){
               if(arr[j]>arr[k]){
                   temp = arr[j];
                  arr[j] = arr[k];
                  arr[k] = temp;
               }
            }
         }
        arr[++i]=arr[0];
       
      ;
        
        System.out.println("the smallest element in an array is : "+arr[++i]);
        
        
        
    }
}
