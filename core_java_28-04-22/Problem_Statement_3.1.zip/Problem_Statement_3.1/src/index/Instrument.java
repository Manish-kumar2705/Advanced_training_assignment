package index;

public abstract class Instrument {
	public abstract void play();
}
