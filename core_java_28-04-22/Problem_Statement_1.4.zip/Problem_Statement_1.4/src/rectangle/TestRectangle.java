package rectangle;

import java.util.Scanner;

public class TestRectangle {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Rectangle  obj2 = new Rectangle(1, 1);
		System.out.print("Enter length of rectangle: ");
		float len= sc.nextFloat();
		sc.nextLine();
		obj2.setLength(len);
		System.out.print("Enter breadth of rectangle: ");
		float brth= sc.nextFloat();
		sc.nextLine();
		obj2.setBreadth(brth);
		obj2.calculateArea();
		obj2.calculatePerimeter();
		obj2.displayArea();
		obj2.displayPerimeter();
		
	}

}
