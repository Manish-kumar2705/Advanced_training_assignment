package book;

public class Book {
	
 String bookTitle;
 
 public Book() {
	super();
	// TODO Auto-generated constructor stub
}
float bookPrice=0f;
 
public String getBookTitle() {
	return bookTitle;
}
public void setBookTitle(String bookTitle) {
	this.bookTitle = bookTitle;
}
public float getBookPrice() {
	return bookPrice;
}
public void setBookPrice(float bookPrice) {
	this.bookPrice = bookPrice;
}
 
 

}
